<?php

namespace App\Http\Controllers;

use App\Models\GroupBooking;
use Illuminate\Http\Request;
use App\Notifications\NewPassengerNotification;
use App\Notifications\Proposalprice;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon;
use Validator;
use DB;
use Auth;
use Illuminate\Support\Str;

class GroupBookingController extends Controller
{
    public function group()
    {
        // $groupBookings = GroupBooking::all();

        $todayCount = GroupBooking::whereDate('created_at', Carbon::today())->count();
        
        $weekStart = Carbon::now()->startOfWeek();
        $weekEnd = Carbon::now()->endOfWeek();
        $weekCount = GroupBooking::whereBetween('created_at', [$weekStart, $weekEnd])->count();
        
        $monthCount = GroupBooking::whereMonth('created_at', Carbon::now()->month)->count();

        $todayPendingCount = GroupBooking::where('status', 'pending')
            ->whereDate('created_at', Carbon::today())
            ->count();
        
        $todayApprovedCount = GroupBooking::where('status', 'approved')
            ->whereDate('created_at', Carbon::today())
            ->count();
        
        $weekStart = Carbon::now()->startOfWeek();
        $weekEnd = Carbon::now()->endOfWeek();
        
        $weekPendingCount = GroupBooking::where('status', 'pending')
            ->whereBetween('created_at', [$weekStart, $weekEnd])
            ->count();
        
        $weekApprovedCount = GroupBooking::where('status', 'approved')
            ->whereBetween('created_at', [$weekStart, $weekEnd])
            ->count();
        
        $monthPendingCount = GroupBooking::where('status', 'pending')
            ->whereMonth('created_at', Carbon::now()->month)
            ->count();
        
        $monthApprovedCount = GroupBooking::where('status', 'approved')
            ->whereMonth('created_at', Carbon::now()->month)
            ->count();
        
          $Auth=Auth::user()->type;
          $company=Auth::user()->company_id;

        if ($Auth=='Supper') {
            $groupBookings = DB::table('group_bookings')
            ->orderBy('created_at', 'desc')
            ->get();
        }else {
           $groupBookings = DB::table('group_bookings')
            ->where('company_id',$company)
            ->orderBy('created_at', 'desc')
            ->get();
        }

        return view('group', compact('groupBookings',
            'todayCount',
            'weekCount',
            'monthCount',
            'todayPendingCount',
            'todayApprovedCount','weekPendingCount','weekApprovedCount','monthPendingCount','monthApprovedCount'));
    }

    public function proposal(Request $request){
        $book=$request->input('booking_number');
        return$data=DB::table('group_bookings')->where('booking_number',$book)->get();
        $prooser = GroupBooking::findOrFail($id);
        $prooser->proposted = $request->input('proposted');
        $prooser->status = 'pending';
        $prooser->save();

    }


    public function search(Request $request)
    {
        $query = $request->get('query');

        $bookings = GroupBooking::where('group_name', 'LIKE', "%$query%")
            ->orWhere('booking_number', 'LIKE', "%$query%")
            ->get();

        return response()->json($bookings);
    }


    public function create()
    {
        return view('group_bookings.create');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
    'customer_id' => 'required',
    'company_id' => 'required',
    // 'booking_number' => 'required',
    'group_name' => 'required',
    'flight_number' => 'required',
    'group_size' => 'required',
    // 'emails' => 'required',
    'emails.*' => 'email',
]);

// Check if validation fails
if ($validator->fails()) {
    // Handle validation errors
    return response()->json([
        'error' => $validator->errors(),
    ], 400);
}

$bookingNumber = Str::random(8); // Generate a random alphanumeric string with length 8
while (GroupBooking::where('booking_number', $bookingNumber)->exists()) {
    $bookingNumber = Str::random(8); // Generate a new random alphanumeric string
}

// Use the generated unique booking_number in your code
$request->merge(['booking_number' => $bookingNumber]);


        
         $emails = explode(',', $request->input('emails'));
         $savedEmails = [];

          $emailString = $request->input('emails');

    // Extract emails using regular expressions
    $pattern = '/[\s,]+/'; // Match one or more spaces or commas
    preg_match_all('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/', $emailString, $matches);
    $emailArr = $matches[0];

        // Save each email to the database
        foreach ($emails as $email) {
            // return ['email' => trim($email)];
            $urls = 'https://arik-group-booking.vercel.app/passenger?email='.$email.'&&booking_number='.$request->input('booking_number');
            $booking_number=$request->input('booking_number');
            Notification::route('mail', $email)
            ->notify(new NewPassengerNotification($urls));
            array_push($savedEmails,$email);
        }



// Create a new instance of the GroupBooking model
$groupBooking = new GroupBooking();
// Set the properties based on the validated input
$groupBooking->customer_id = $request->input('customer_id');
$groupBooking->company_id = $request->input('company_id');
$groupBooking->booking_number = $request->input('booking_number');
$groupBooking->group_name = $request->input('group_name');
$groupBooking->flight_number = $request->input('flight_number');
$groupBooking->trip_type = $request->input('trip_type');
$groupBooking->group_size = $request->input('group_size');
$groupBooking->departure_date = $request->input('departure_date');
$groupBooking->return_date = $request->input('return_date');
$groupBooking->message = $request->input('message');
// $groupBooking->emails =$request->input('emails');
$groupBooking->save();

if ($groupBooking) {
    DB::table('timelines')
        ->insert([
            'user'=>'customer_id',
            'booking_number'=>$request->input('booking_number'),
          'activity' => 'a Booking initiated',
          'activity_type' => 'Booked',
          'status' => 'Awaiting',
          'created_at'=>Carbon::now(),
        ]);
    return response()->json(['status'=>'success',
'date'=>$groupBooking]);
}

 return response()->json(['status'=>'error'],200);
    }

    public function groupshow($id)
    {
        $groupBooking = GroupBooking::findOrFail($id);

        return view('groupDetail', compact('groupBooking'));
    }

      public function detailshow($id)
    {
        $groupBooking = GroupBooking::findOrFail($id);

        return view('booking.details', compact('groupBooking'));
    }

        public function updatePrice(Request $request, $id)
    {
        $prooser = GroupBooking::findOrFail($id);
        $prooser->proposted = $request->input('proposted');
        $prooser->status = 'pending';
        $prooser ->booking_number;
        $prooser->save();
        if ($prooser) {

    DB::table('timelines')
        ->insert([
            'user'=>Auth::user()->name,
            'booking_number'=>$prooser ->booking_number,
          'activity' => 'a price proposer initiated',
          'activity_type' => 'Booked',
          'status' => 'pending',
          'created_at'=>Carbon::now(),
        ]);

           $email = DB::table('customers')
    ->join('group_bookings', 'customers.id', 'group_bookings.customer_id')
    ->select('email','customer_id')
    ->latest('group_bookings.created_at')
    ->first();

     $mail=$email->email;
     $customer_id=$email->customer_id;
     $price=$request->input('proposted');
      $urls = 'https://arik-group-booking.vercel.app/group-review?customer_id='.$customer_id;
        // Notification::route('mail', $mail)
        // ->notify(new Proposalprice($price,$urls));
        }
        return redirect()->back()->with('success', 'Passenger updated successfully.');
    }

    public function edit($id)
    {
        $groupBooking = GroupBooking::findOrFail($id);

        return view('group_bookings.edit', compact('groupBooking'));
    }

    public function update(Request $request, $id)
    {
        $groupBooking = GroupBooking::findOrFail($id);
        $groupBooking->booking_number = $request->input('booking_number');
        $groupBooking->group_name = $request->input('group_name');
        $groupBooking->flight_id = $request->input('flight_id');
        $groupBooking->group_size  = $request->input('group_size ');
        $groupBooking->save();

        return redirect()->route('group_bookings.index')->with('success', 'Group Booking updated successfully.');
    }

    public function destroy($id)
    {
        $groupBooking = GroupBooking::findOrFail($id);
        $groupBooking->delete();

        return redirect()->route('group_bookings.index')->with('success', 'Group Booking deleted successfully.');
    }

       public function Awaiting()
    {
         $Auth=Auth::user()->type;
          $company=Auth::user()->company_id;

        if ($Auth=='Supper') {
            $groupBookings = DB::table('group_bookings')
            ->orderBy('created_at', 'desc')
            ->get();
        }else {
           $groupBookings = DB::table('group_bookings')
            ->where('company_id',$company)
            ->where('status','Awaiting')
            ->orderBy('created_at', 'desc')
            ->get();
        }
        return view('booking.awaiting',compact('groupBookings'));
    }

    public function Pending()
    {
         $Auth=Auth::user()->type;
          $company=Auth::user()->company_id;

        if ($Auth=='Supper') {
            $groupBookings = DB::table('group_bookings')
            ->orderBy('created_at', 'desc')
            ->get();
        }else {
           $groupBookings = DB::table('group_bookings')
            ->where('company_id',$company)
            ->where('status','pending')
            ->orderBy('created_at', 'desc')
            ->get();
        }
        return view('booking.pending',compact('groupBookings'));
    }

      public function Approved()
    {
         $Auth=Auth::user()->type;
          $company=Auth::user()->company_id;

        if ($Auth=='Supper') {
            $groupBookings = DB::table('group_bookings')
            ->orderBy('created_at', 'desc')
            ->get();
        }else {
           $groupBookings = DB::table('group_bookings')
            ->where('company_id',$company)
            ->where('status','Approved')
            ->orderBy('created_at', 'desc')
            ->get();
        }
        return view('booking.approved',compact('groupBookings'));
    }
}
