<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notifications\WelcomeNotification;
use Tymon\JWTAuth\Contracts\JWTSubject;
use App\Models\Customer;
use Validator;
use Auth;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;
class CustomerController extends Controller
{
      public function __construct()
    {
        $this->middleware('auth.api',['except'=>['login','logins','register','logout','profile']]);
    }

   public function loginsss(Request $request)
{
    $validator = Validator::make($request->all(), [
        'email' => ['required', 'string', 'email'],
        'password' => ['required', 'string'],
    ]);

    if ($validator->fails()) {
        return response()->json(['error' => 'Validation failed'], 422);
    }

    $credentials = $request->only('email', 'password');

    if (Auth::guard('api')->attempt($credentials)) {
        $user = Auth::guard('api')->user(); $token = JWTAuth::fromUser($user);
        // $token = $user->createToken('MyApp')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $user,
        ]);
    }

    return response()->json(['error' => 'Unauthorized'], 401);
}


    public function register(Request $request)
{
    // Validate the request data
    $validator = Validator::make($request->all(), [
        'email' => 'required|email|unique:customers',
        'password' => 'required|min:6',
    ]);

    if ($validator->fails()) {
        return response()->json(['error' => $validator->errors()], 422);
    }

    // Create a new user
    $user = Customer::create([
        'email' => $request->input('email'),
        'password' => bcrypt($request->input('password')),
    ]);

    // Generate a JWT token for the user
    $token =auth()->login($user);

    // Return the token to the client
    return response()->json(['token' => $token]);
}


  public function registers(Request $request)
    {

       $ff=Validator::make($request->all(), [
            'email' => ['required', 'string', 'email', 'max:255', 'unique:customers'],
            'password' => ['required', 'string', 'min:2'],
        ]);

        if ($ff->fails()) {
            // code...
             return response()->json(['error' => $validator->errors()], 422);
        }

        
            $data=new Customer;
            $data->email = $request->email;
            $data->password =bcrypt($request->password);
            $data->save();

            if ($data) {
                 return response()->json([
                'status' => 'success',
                'user' => $data
                
            ]);
     }  
    }


public function logins(Request $request)
{
    $validator = Validator::make($request->all(), [
        'email' => ['required', 'string', 'email'],
    ]);

    if ($validator->fails()) {
        return 'field required';
    }

    $credentials = $request->only('email');
    $user = Customer::firstOrCreate($credentials);
    $token = JWTAuth::fromUser($user);// Regenerate the token if needed

    if ($user->wasRecentlyCreated) {
        Auth::guard('api')->login($user);
        $user->notify(new WelcomeNotification($user));
        return response()->json([
            'token' => 'Bearer ' . $token, // Add 'Bearer ' prefix to the token
            'user' => $user,
        ]);
    }
     Auth::login($user);
     Auth::guard('api')->login($user);
     Auth::onceUsingId($user->id);
    return response()->json([
        'token' => $token, // Add 'Bearer ' prefix to the token
        'user' => $user,
    ]);
}



public function profile($id)
{
    // $id = $request->input('id');
    $user = Customer::find($id);

    if ($user) {
        return response()->json([
            'status' => 'success',
            'user' => $user
        ]);
    }

    return response()->json([
        'error' => 'User not found.'
    ], 400);
}

  public function profiles(Request $request)
{
    try {
        $user = JWTAuth::parseToken()->authenticate();
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }
    } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
        return response()->json(['message' => 'Token expired'], 401);
    } catch (\Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
        return response()->json(['message' => 'Invalid token'], 401);
    } catch (\Tymon\JWTAuth\Exceptions\JWTException $e) {
        return response()->json(['message' => 'Token absent'], 401);
    }

    return response()->json([
        'status' => 'success',
        'user' => $user
    ]);
}
    public function logout()
{
    // Invalidate the token
    JWTAuth::invalidate(JWTAuth::getToken());

    // Clear the authenticated user from the current request
    Auth::guard('api')->logout();

    return response()->json(['message' => 'Logged out successfully']);
}

    public function update(Request $request, $id)
    {
        $data = Customer::findOrFail($id);
        $data->update($request->all());
    return "Updated successfully".','.$data;
    }

    public function delete(Request $request, $id)
    {
        $data = Customer::findOrFail($id);
        $data->delete();

        return 'item deleted';
    }

}
