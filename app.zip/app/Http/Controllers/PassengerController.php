<?php

namespace App\Http\Controllers;

use App\Models\Passenger;
use App\Notifications\Passengerfill;
use Illuminate\Support\Facades\Notification;
use Illuminate\Http\Request;
use Validator;
use DB;
use Auth;

class PassengerController extends Controller
{

    //    public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    public function passenger()
    {
        $passengers = Passenger::all();

        return view('passenger.index', compact('passengers'));
    }

    public function create()
    {
        return view('passengers.create');
    }

    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
    'name' => 'required',
    'email' => 'required',
    'phone' => 'required',
    'booking_number' => 'required',
    'passport_no' => 'required',
    'dob' => 'required',
                    ]);

// Check if validation fails
if ($validator->fails()) {
    // Handle validation errors
    return response()->json([
        'error' => $validator->errors(),
    ], 400);
}
        $passenger = new Passenger();
        $passenger->name = $request->input('name');
        $passenger->email = $request->input('email');
        $passenger->phone = $request->input('phone');
        $passenger->passport_no = $request->input('passport_no');
        $passenger->dob = $request->input('dob');
        $passenger->booking_number = $request->input('booking_number');
        $passenger->save();
        $email=$request->input('email');
if ($passenger) {
    Notification::route('mail', $email)
            ->notify(new Passengerfill($email));
    return response()->json(['status'=>'success',
'date'=>$passenger]);
}

 return response()->json(['status'=>'error'],200);
    }
      

    public function editPassenger($id)
    {
        $passenger = Passenger::findOrFail($id);

        return view('passenger.show', compact('passenger'));
    }

    public function edit($id)
    {
        $passenger = Passenger::findOrFail($id);

        return view('passengers.edit', compact('passenger'));
    }

    public function updatePassenger(Request $request, $id)
    {
        $passenger = Passenger::findOrFail($id);
        $passenger->name = $request->input('name');
        $passenger->email = $request->input('email');
        $passenger->phone = $request->input('phone');
        $passenger->flight_id = $request->input('flight_id');
        $passenger->save();

        return redirect()->back()->with('success', 'Passenger updated successfully.');
    }

    public function deletePassenger($id)
    {
        $passenger = Passenger::findOrFail($id);
        $passenger->delete();

        return redirect()->route('passengers.index')->with('success', 'Passenger deleted successfully.');
    }
}
