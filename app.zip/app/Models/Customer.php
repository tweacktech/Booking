<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable;  
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;

class Customer extends Model implements Authenticatable,JWTSubject
{
     use HasApiTokens, HasFactory, Notifiable;

    protected $fillable=
    [
        'email',
        'password',
    ];


  
    public function getAuthIdentifierName()
    {
        return 'id';
    }

    public function getAuthIdentifier()
    {
        return $this->getKey();
    }

    public function getAuthPassword()
    {
        return $this->password;
    }

    public function getRememberToken()
    {
        return null;
    }

    public function setRememberToken($value)
    {
        // Do nothing
    }

    public function getRememberTokenName()
    {
        return null;
    }

   // public function getJWTIdentifier()
   //  {
   //      return $this->getKey();
   //  }

   //  /**
   //   * Return a key value array, containing any custom claims to be added to the JWT.
   //   *
   //   * @return array
   //   */
   //  public function getJWTCustomClaims()
   //  {
   //      return [];
   //  }

 
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }
}
