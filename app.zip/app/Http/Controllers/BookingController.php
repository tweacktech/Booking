<?php

namespace App\Http\Controllers;

use App\Models\GroupBooking;
use Illuminate\Http\Request;
use App\Notifications\NewPassengerNotification;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon;
use Validator;
use DB;
use Auth;

class BookingController extends Controller
{
    
    public function store(Request $request)
    {

    	
        $request->validate([
            'flight_id' => 'required',
            'customer_id' => 'required',
            'company_id' => 'required',
            'group_name' => 'required',
            'trip_type' => 'required',
            'departure_date' => 'required|date',
            'return_date' => 'required|date',
            'message' => 'nullable',
            'group_size' => 'required|integer',
            // 'emails.*' => 'email',
            'booking_number' => 'required|unique:bookings',
        ]);

        
    	 $emails = explode(',', $request->input('emails'));
         $savedEmails = [];

          $emailString = $request->input('emails');

    // Extract emails using regular expressions
    $pattern = '/[\s,]+/'; // Match one or more spaces or commas
    preg_match_all('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/', $emailString, $matches);
    $emailArr = $matches[0];

        // Save each email to the database
        foreach ($emailArr as $email) {
            // return ['email' => trim($email)];
            // Notification::route('mail', $email)
            // ->notify(new NewPassengerNotification());
            array_push($savedEmails,$email) ;
            // $savedEmails[] = $savedEmail->email; 
            // Add saved email to the array
        }


       

        // Create a new booking
        $booking = new GroupBooking();
        $booking->flight_id = $request->input('flight_id');
        $booking->customer_id = $request->input('customer_id');
        $booking->company_id = $request->input('company_id');
        $booking->group_name = $request->input('group_name');
        $booking->trip_type = $request->input('trip_type');
        $booking->departure_date = $request->input('departure_date');
        $booking->return_date = $request->input('return_date');
        $booking->message = $request->input('message');
        $booking->group_size = $request->input('group_size');
        $booking->emails = $request->input('emails');
        $booking->booking_number = $request->input('booking_number');
        $booking->save();
        // Redirect to a success page or do something else
        return redirect()->back()->with('success', 'Booking created successfully!');
    }




    

}
